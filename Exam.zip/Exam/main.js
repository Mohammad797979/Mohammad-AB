let html = ""
let fetchData = async () => {
  try {
    let res = await axios.get("https://jsonplaceholder.typicode.com/photos")
    res.data.forEach((element) => {
      html += `div class="product">
<h1>
${element.id}</h1>
<img src "${element.url}" /> 
</div>`
document.querySelectorAll("div.parent").innerHTML= html
    })
  }
  catch (error) {
    console.log("errorrrr")

  }

}


$("div.parnet").show();
setTimeout(function() {
    $("div.parent").remove();
}, 2000);
let menuBar = document.querySelector('#menuBar')
let mobileMenu = document.querySelector('#mobileMenu')
let closeMenu = document.querySelector('#closeMenu')

menuBar.addEventListener('click', function(){
    mobileMenu.classList.remove('hidden')
})

closeMenu.addEventListener('click', function(){
    mobileMenu.classList.add('hidden')
})

let username =+prompt("نام کاربری وارد کنید")
let password = +prompt("پسووردتان را وارد کنید")
let email =+prompt("ایمیلتان را وارد کنید")

if (username=="Mohammad"){
    console.log("نام کاربری درست است")

    if(password==="123456"){
        console.log("رمز عبور درست است")
        if(email==="Mohammad@gmail.com"){
            console.log("ایمیل درست است")
        }
        else{
            console.log("رمز عبور درست است")
        }
    }
}
else{
    console.log("نام کاربری درست است")
}


var content = document.getElementsByTagName('body')[0];
var darkMode = document.getElementById('dark-change');
darkMode.addEventListener('click', function(){
    darkMode.classList.toggle('active');
    content.classList.toggle('night');
})

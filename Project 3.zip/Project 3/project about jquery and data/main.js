let flag = true

$("button.click").click(
    function () {
        if(flag === true) {
            $(this).addClass("yellow")
            flag = false


        }
        else{
            $(this).removeClass("yellow")
            flag=true
        }
    }
)

("div#root").css({
width:"500px",
backgroundColor:"lightblue",
padding:"50px",
boxSizing:"border-box",
margin:"50px auto",


})



let fetchData = async () => {
    let html = ""
    let res = await fetch("http://localhost:3000/prodouct")
    let data = await res.json()

    data.forEach((element) => {
        html += `
        <div class="product">
  <h1>
     ${element.name}</h1>
    <img src="${element.image}" />
    <p>${element.price}</p>
    ${element.publish === true
                ? `   <span>موجود</span>`
                : `   <span class="bgRed">ناموجود</span>`
            }
</div>`
    })
    document.querySelector("div.parent").innerHTML=html
}
document.addEventListener("DOMContentLoaded", fetchData)